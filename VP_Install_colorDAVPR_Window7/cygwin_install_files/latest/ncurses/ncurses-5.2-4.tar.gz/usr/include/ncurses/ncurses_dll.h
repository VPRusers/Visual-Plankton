/* $Id: ncurses_dll.h,v 1.1 2000/11/07 00:46:37 cwilson Exp $ */


#if defined(__CYGWIN__)
#  if defined(NCURSES_DLL)
#    if defined(NCURSES_STATIC)
#      undef NCURSES_STATIC
#    endif
#    if defined(ALL_STATIC)
#      undef ALL_STATIC
#    endif
#  endif
#  undef NCURSES_IMPEXP
#  undef NCURSES_API
#  undef NCURSES_EXPORT(type,symbol)
#  undef NCURSES_EXPORT_VAR(type)
#  if defined(NCURSES_DLL)
/* building a DLL */
#    define NCURSES_IMPEXP __declspec(dllexport)
#  elif defined(NCURSES_STATIC) || defined(ALL_STATIC)
/* building or linking to a static library */
#    define NCURSES_IMPEXP
#  else
/* linking to the DLL */
#    define NCURSES_IMPEXP __declspec(dllimport)
#  endif
#  define NCURSES_API __cdecl
#  define NCURSES_EXPORT(type,symbol) NCURSES_IMPEXP type NCURSES_API symbol
#  define NCURSES_EXPORT_VAR(type) NCURSES_IMPEXP type
#endif

/* Take care of non-cygwin platforms */
#if !defined(NCURSES_IMPEXP)
#  define NCURSES_IMPEXP
#endif
#if !defined(NCURSES_API)
#  define NCURSES_API
#endif
#if !defined(NCURSES_EXPORT)
#  define NCURSES_EXPORT(type,symbol) NCURSES_IMPEXP type NCURSES_API symbol
#endif
#if !defined(NCURSES_EXPORT_VAR)
#  define NCURSES_EXPORT_VAR(type) NCURSES_IMPEXP type
#endif
