
GLUT, GLU and OpenGL header files; GLUI header file and library
---------------------------------------------------------------

Andr� Bleau, bleau@igb.umontreal.ca

Package opengl-1.1.0-3 updated 20/11/2000


*** WARNING ***
---------------

This package does _not_ contain a complete set of files for building Open GL
-based programs. It contains only the missing pieces in the Cygwin environment
to build programs calling functions from opengl32.dll and glu32.dll provided 
by Microsoft in Windows NT 4.0 and Windows 2000. I don't know about Windows 
95/98. 

There is also an include file and a DLL for GLUT-based for building programs 
and an include file and static libraries for GLUI-based programs.



Installation
------------

Use the setup utility from www.cygwin.com.



Linking of code calling OpenGL, GLU, GLUT
-----------------------------------------

Add -lglut32 -lglu32 -lopengl32 to your link command.



Linking of code calling OpenGL, GLU, GLUT, and GLUI
---------------------------------------------------

Add -lglui -lglut32 -lglu32 -lopengl32 to your link 
command. 



Linking of code calling OpenGL, GLU, GLUT, GLUI, and GLUIX
----------------------------------------------------------

Add -lgluix -lglui -lglut32 -lglu32 -lopengl32 to your link 
command. 

libglui.a and libgluix.a are static libraries.

libglut32.a, libglu32.a and libopengl32.a interface with Windows 
NT/2000. I don't know about Windows 95/98. They are part of Cygwin 1.1.x.



Content of the tar ball
-----------------------

        usr/bin/glut32.dll
For GLUT 3.7.
From http://reality.sgi.com/mjk_asd/glut3/glut3.html; not modified. Move 
to some directory in your path or add usr/local/bin to your path.

	usr/doc/opengl-1.1.0/README.txt
This file.

	usr/doc/opengl-1.1.0/glui_manual_v2_beta.pdf
For GLUI 2.0 beta.
From http://www.cs.unc.edu/~rademach/glui/ . Documentation for
GLUI 2.0 beta.

	usr/doc/opengl-1.1.0/glui_menuButton.pdf
	usr/doc/opengl-1.1.0/glui_panel.pdf
	usr/doc/opengl-1.1.0/glui_windows.pdf
For GLUI 2.02 beta.
Documentation addenda for GLUI 2.02 beta.

	usr/doc/opengl-1.1.0/gluix.pdf
For GLUIX 1.0.
Documentation for GLUIX 1.0.


	usr/doc/opengl-1.1.0/glut-3.spec.pdf
For GLUT 3.7
From http://reality.sgi.com/mjk_asd/glut3/glut3.html . Documentation for
GLUT 3.7.

        usr/include/GL/gl.h
For OpenGL 1.1.0.
Modified version of usr/X11R6/include/GL/gl.h from 
ftp://sourceware.cygnus.com/pub/cygwin/xfree/xc-4-binaries/xfree86-4.0-devel.tar.bz2 
to add __attribute__ ((__stdcall__)) to the declaration of functions to 
enable linking with opengl32.dll via usr/lib/libopengl32.a .

        usr/include/GL/glu.h
For GLU 1.2.2.
Modified version of usr/X11R6/include/GL/glu.h from 
ftp://sourceware.cygnus.com/pub/cygwin/xfree/xc-4-binaries/xfree86-4.0-devel.tar.bz2 
to add __attribute__ ((__stdcall__)) to the declaration of functions to 
enable linking with glu32.dll via usr/lib/libglu32.a .

        usr/include/glui.h
For GLUI 2.02 beta.
From http://www.cs.unc.edu/~rademach/glui/; modified to include version 2.02 additions.
Header file for the GLUI tool kit version 2.02 beta.

        usr/include/gluix.h
For GLUIX 1.0.
Header file for extensions to the GLUI tool kit.

        usr/include/GL/glut.h
For GLUT 3.7.
From http://reality.sgi.com/mjk_asd/glut3/glut3.html; modified to add 
__attribute__ ((__stdcall__)) to the declaration of functions to enable 
linking with glut32.dll via usr/lib/libglut32.a . Jerome G. Benoit 
provided hints about how to do it and provided an example; thanks Jerome!

        usr/lib/libglui.a
For GLUI 2.02 beta.
A static library compiled from modified sources of the GLUI tool kit 
version 2.02 beta, found at http://www.cs.unc.edu/~rademach/glui/. 
Compilation with -O3 optimization. I highly recommend this very useful 
tool kit.

        usr/lib/libgluix.a
For GLUIX 1.0.
A static library for extensions to the GLUI tool kit.
Compilation with -O3 optimization. 

Modified sections of the .h files are bracketed by
#ifdef (__CYGWIN__)
#endif



What has changed since opengl-1.2.1-2
-------------------------------------

The package now installs in /usr instead of /usr/local. If you had a previous version
of the opengl package installed, you may delete the following files:
	/READMEopengl-1.1.0-2.txt
        /usr/local/include/GL/glut.h
        /usr/local/bin/glut32.dll
	/usr/local/doc/opengl-1.1.0/glui_manual_v2_beta.pdf
	/usr/local/doc/opengl-1.1.0/glut-3.spec.pdf
        /usr/local/include/GL/gl.h
        /usr/local/include/GL/glu.h
        /usr/local/include/glui.h
        /usr/local/lib/libglui.a


What has changed since opengl-1.2.1-1
-------------------------------------

The previous package name errounously suggested that it was for Open GL 1.2.1 while
it is in fact for the Open GL 1.1.0 DLL provided by Microsoft.

The declaration of glGetString in gl.h has been corrected to include the APIENTRY
qualifier.

