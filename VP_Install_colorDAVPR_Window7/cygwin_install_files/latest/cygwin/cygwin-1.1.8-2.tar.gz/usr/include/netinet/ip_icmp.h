#ifndef _NETINET_IP_ICMP_H
#define _NETINET_IP_ICMP_H

#include <cygwin/icmp.h>

#endif /* _NETINET_IP_ICMP_H */
