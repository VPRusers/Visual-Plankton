#ifndef _NETINET_TCP_H
#define _NETINET_TCP_H

/* Maybe add some definitions, someday */

#endif
