#ifndef _NETINET_IN_SYSTM_H
#define _NETINET_IN_SYSTM_H

#include <cygwin/in_systm.h>

#endif /* _NETINET_IN_SYSTM_H */
