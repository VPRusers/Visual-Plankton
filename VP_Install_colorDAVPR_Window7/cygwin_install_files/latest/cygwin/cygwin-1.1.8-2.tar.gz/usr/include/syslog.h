#ifndef _SYSLOG_H
#define _SYSLOG_H

#include <sys/syslog.h>

#endif /* _SYSLOG_H */
