#ifndef _STRINGS_H
#define _STRINGS_H

#include <string.h>

#endif /* _STRINGS_H */
