/* sys/mtio.h header file for Cygwin.  */

#ifndef _SYS_MTIO_H
#define _SYS_MTIO_H

#include <cygwin/mtio.h>

#endif /* _SYS_MTIO_H */
