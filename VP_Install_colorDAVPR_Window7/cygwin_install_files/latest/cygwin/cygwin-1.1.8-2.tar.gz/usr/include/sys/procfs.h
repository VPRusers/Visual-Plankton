/* sys/procfs.h header file for Cygwin.  */

#ifndef _SYS_PROCFS_H
#define _SYS_PROCFS_H

#include <cygwin/core_dump.h>

#endif /* _SYS_PROCFS_H */
