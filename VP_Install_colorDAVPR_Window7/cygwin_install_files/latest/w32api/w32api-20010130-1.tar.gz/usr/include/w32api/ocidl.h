#ifndef _OCIDL_H
#define _OCIDL_H

#include <ole2.h>
#include <olectl.h>

#endif
