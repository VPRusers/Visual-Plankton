

#if defined(__CYGWIN__)
#  if defined(READLINE_DLL)
#    if defined(READLINE_STATIC)
#      undef READLINE_STATIC
#    endif
#  endif
#  if defined(READLINE_DLL)
/* building a DLL */
#    if !defined(READLINE_IMPEXP)
#      define READLINE_IMPEXP __declspec(dllexport)
#    endif
#  elif defined(READLINE_STATIC)
/* building or linking to a static library */
#    if !defined(READLINE_IMPEXP)
#      define READLINE_IMPEXP
#    endif
#  else
/* linking to the DLL */
#    if !defined(READLINE_IMPEXP)
#      define READLINE_IMPEXP __declspec(dllimport)
#    endif
#  endif

#  if !defined(READLINE_API)
#    define READLINE_API __cdecl
#  endif
#  if !defined(READLINE_EXPORT)
#    define READLINE_EXPORT(type,symbol) READLINE_IMPEXP type READLINE_API symbol
#  endif
#  if !defined(READLINE_EXPORT_VAR)
#    define READLINE_EXPORT_VAR(type) READLINE_IMPEXP type
#  endif
#endif

#if !defined(READLINE_IMPEXP)
#  define READLINE_IMPEXP
#endif
#if !defined(READLINE_API)
#  define READLINE_API
#endif
#if !defined(READLINE_EXPORT)
#  define READLINE_EXPORT(type,symbol) READLINE_IMPEXP type READLINE_API symbol
#endif
#if !defined(READLINE_EXPORT_VAR)
#  define READLINE_EXPORT_VAR(type) READLINE_IMPEXP type
#endif

